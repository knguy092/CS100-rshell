#tests single commands

echo testing single commands
ls
ls -a 
mkdir kevin
rmdir kevin
echo A
echo B
    ls                ;
ls         ;
ls;;;;;;
echo         ls ls ls l s #ls 
    ls;

echo single commands work
echo single commands testing complete
exit
