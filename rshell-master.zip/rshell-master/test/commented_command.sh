#tests commands with comments


echo calling comments now #ls -a
echo the comments work!!!
ls -a #echo this should not display
exit
