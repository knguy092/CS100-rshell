#tests exit and commands with exit

ls -a
echo exit
ls
echo calling exit next
exit
