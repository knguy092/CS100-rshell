((echo a || echo b) && echo c)
(echo a && echo b) && (echo c || echo d)
(echo a && (echo b && echo c) && (echo d && echo f))
echo a && (echo b && echo c)
echo a || (echo b && echo c)
(echo a && echo b) && echo c
(echo a && echo b) || echo c
(echo a || echo b) && (echo c || echo d)
(echo a)
(echo a && echo b)
(echo a || echo b)
echo a && (echo b || echo c) && echo d
echo a || (echo b && ec)
echo a || (echo b && echo c) && echo d
echo a || echo b && (echo c && echo d)
echo a && (echo b)
(echo a) && echo b
((echo A && echo B) || (echo C && echo D && (echo E && echo F)))
echo A || echo B && (echo C && echo D)
echo A || (echo B && echo C) && echo D
(echo A || echo B && echo C) && echo D
( (echo A && echo B && echo C && echo D) )
( (echo A || echo B || echo C || echo D) )
