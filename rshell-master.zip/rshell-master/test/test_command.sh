[ test ] && echo A
[ asdf ] && echo A
[ -f test ] && echo A
[ -f rshell.cpp ] && echo A

test -d test && echo A

test -f test/test.cpp && echo A

test -f test/test2 && echo A
test -d test/test2 && echo A

[sdfa ]

$ [ fsadf]

[ / ]
[ -e test ] && echo A

echo A && [ test ] || echo C

echo A && [ttest ] && echo C


     test    -f   test
test	   -f	test && echo A
test	     -d test && echo A

test	   -s tset

test -f -t
test -f -t && echo A
test -f -t && echo A
testt-ff
testttest
test test && echo A

test -f test || echo A

[ -f	   test       ]
[  -f -d testest    ] && echo A

test -f test/test.cpp      && echo A

[-f test]] && echo A

[ -d test ] && echo A

[ -d test ]&&echo A

test -d test&& echo A

test -d test&&echo A

test saf && echo A
test -f fsaf && echo A
test -d fsadf && echo A
test -e fsadf && echo A
[ saf ]&&echo A
[ test ]&&echo A
[ -f		  test	    ] &&    echo A
[   -d	  testet    ] &&    echo A

[   -d	      test }] || echo A
[ -f	 test ] || echo A

[ /test/test2 ] && echo "path exists"
[ test/test2 ] && echo "path exists"

 exit

